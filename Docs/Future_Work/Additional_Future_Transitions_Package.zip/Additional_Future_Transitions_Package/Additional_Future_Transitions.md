# Additional Future Transitions / Visualizers

Eight selected, music-reactive visualizer concepts, including Neon Lake Basin as the full Shockwave Grid rework target. Despite the historic “Transitions” filename, these are **Visualizer modes**, not image transition effects. The existing seven concept images are retained; Digital Rain adds one new low/high concept sheet. Nothing in this package is a shipping renderer or a claim of measured performance.

**Reference package in the repository:** `Docs/Future_Work/Additional_Future_Transitions_Package.zip`. The existing `Current_Plan.md` owns execution order. In particular, its Shockwave task calls for **spec migration and the Neon Lake Basin rework in one slice**, not a speculative second replacement later.

## Scope and ground rules

- **Implementation substrate:** Qt Quick + Python + OpenGL 4.6 only. No alternate graphics API or secondary presenter is a dependency.
- **Framed 3D means a normal, stationary widget card.** The *Qt Quick card, border, shadow, rounded clipping, layout bounds and Edit affordances stay flat and still.* The **3D content alone** is rendered inside the card and can be orbited/tilted by its camera, as planned for Extruded Bubble. Never draw a separate floating physical 3D picture frame or rotate/translate the whole card. This specifically applies to **Reactive Cubes, Ember Swarm, Waveform Ribbon, Aurora Field and Digital Rain**, and the same presentation policy is the default for the other included 3D scenes unless an operator-authorized mode-specific exception is made.
- **Canonical 3D geometry:** reuse the existing per-mode Scene3D orbit, tilt, camera, projection and CUSTOM/3D freeform rules; keep camera pose separate from authored preset appearance where SRPSS already does. A mode change does not silently enter CUSTOM or replace its geometry authority. Compute camera-fit/clipping bounds against the inner card, not a guessed outer box. No second Qt window, QQuickWidget, offscreen presenter or camera ownership copy.
- **Ownership model:** all of these should land through **the new spec method**, not bespoke hidden settings ownership.
- **Shared architecture rules still apply:** no second presentation authority, no separate swap owner, no self-driven repaint loops, no extra independent audio analysis authority, no permanent background simulation, no dormant polling, no eager always-on allocations.
- **Goal of “genuine parity”:** achieve the approved low/high-react look, 3D spatial coherence across useful user-selected orbit angles, and equally convincing musical motion, not just one attractive static screenshot. At least **one deliberately authored preset per selected mode** should visibly approach the paired mock in both quiet and sustained loud passages; the mocks are visual targets, not fixed pixel oracles, and artistic presets remain operator-editable.
- **Presentation/camera test:** test orbit and tilt *inside the fixed card*, rounded clip/border preservation, freeform geometry, per-mode camera persistence, resize/DPR and display transfer. Visual floor/reflection geometry, where applicable, belongs to the scene inside the card.
- **Reactivity default lean:** each visualizer should have at least one unmistakable **primary musical response**, complemented by brightness / colour / density / lane activity / bounded glow / secondary deformation. Primary does not mean violent: preserve **impactful but not alarming** reactivity, readable scene identity, and smooth musical continuity.
- **Critical audio pitfall:** low notes, kicks and transient bursts must not wash out the entire frame, overwhelm authored colour, trigger mass particle/glyph admission, or snap geometry into uncomfortable extremes. Use onset-localized accents, energy budgets, bounded emission, controlled attack/decay, and mode-appropriate sustained-passage response. Do not achieve “responsiveness” by flattening the shared DSP, adding competing AGC/floors, changing Bubble's temporal fidelity, or lowering test floors.
- **Spec method requirement:** every mode below should be represented through the current spec-led settings architecture (`visualizer_mode_settings` / mode descriptors / mode-owned declarations), with clear capability ownership, canonical defaults, spec-owned controls, dormant inactive state, and no one-off UI plumbing.

---

## Confirmed visual design decisions (2026-10-13)

1. **All included modes use the new spec method.** Spec owns Settings; the existing camera/geometry/preset/CUSTOM owners remain canonical, never a second editor or renderer authority.
2. **Framed, orbitable 3D = flat stationary Qt Quick card + movable internal camera.** Explicitly for Reactive Cubes, Ember Swarm, Waveform Ribbon, Aurora Field and Matrix / Digital Rain, with appropriate internal 3D presentation for Vortex Tunnel, Neon Lake Basin and Orbit Lattice. The box around a mock is *not* a 3D object to build.
3. **Waveform Ribbon includes the wet, road-tar/concrete reflective floor inside the 3D scene.** Render actual materially coherent reflections/lighting from orbit angles; at least one preset should approach that imagery.
4. **Digital Rain adds no motion-sickness shortcut.** Constant-seeming vertical text descent, deeper camera-orbitable layers, selective/possibly LOD extruded glyphs, careful near/far fades, and strictly localized bass/transient glow/ripple response.
5. **Neon Lake Basin replaces the flat Shockwave presentation during spec migration.** A terrain editor defines raised mountain cells; unraised zero-height regions become water, and both surfaces have different configurable audio reactions.
6. **Existing seven images remain the reference mocks.** Only Digital Rain receives a new eighth concept sheet; do not replace the approved art with collages or floating 3D frames.

---

## Selected concepts in this package

1. Reactive Cubes
2. Vortex Tunnel
3. Neon Lake Basin *(Shockwave Grid rework candidate)*
4. Ember Swarm
5. Waveform Ribbon
6. Orbit Lattice
7. Aurora Field
8. Matrix / Digital Rain

All **eight** corresponding concept images are included. Each image contains a low-react and high-react visual target; existing images 1–7 are preserved byte-for-byte from the prior archive. The Digital Rain image is the **only newly added mock**.

---

## 1. Reactive Cubes

### Fixed card / orbitable 3D stage (required)
The scene is rendered inside the **normal, stationary, bordered SRPSS widget card**; cubes occupy real scene depth and user Alt-orbits/tilts the camera *inside* the card. Never turn the widget/card itself into a floating box. Reuse canonical per-mode 3D fit, clipping, projection and freeform geometry rules. As the view changes, cube groups retain stable positions and coherent near/far scale and occlusion; use instancing, not a Python object or draw call per cube.

**Included mock:** `reactive_cubes_calm_to_energetic.png`

### Concept
A field of glowing cubes in 3D space. Low react presents a sparse, readable arrangement with restrained glow and separation. High react increases cube count, rotation, clustering, light intensity, and local energy relationships without turning into unreadable debris.

### Feasibility
**Feasible with future shared Scene3D architecture.**
This is one of the more straightforward candidates because it can lean heavily on shared 3D instancing and bounded per-instance transforms.

### Architecture needed for genuine parity
- Shared Scene3D instanced mesh rendering for cube populations.
- Mode-owned logical state that drives:
  - cube count / admission,
  - scale ranges,
  - rotation speed,
  - clustering / grouping,
  - glow intensity,
  - optional connection or lane energy.
- Shared stream/uniform upload for per-frame transforms and mode state.
- Optional compacted population path if the active cube count becomes large enough to justify it.
- Shared bloom / reflection support as opt-in quality features; material/edge highlights should remain recognizably three-dimensional from alternate camera angles.
- Tiered quality ceilings for:
  - cube count,
  - connection lines / trails,
  - post-process intensity.
- Spec-owned settings for density, spread, spin response, clustering strength, glow, colour strategy, and optional grouping behavior.

### Reactivity contract
Primary reactive changes should be:
- cube count,
- cube scale,
- rotation rate,
- clustering / loosening,
- glow and colour intensity.

Secondary reactive changes may include:
- depth spread,
- connection streaks,
- local bursts of lane activity.

### Pitfalls to avoid
- Do **not** make high react equal “random explosion of cubes.”
- Avoid teleporting or hard-popping population changes unless intentionally stylized.
- Avoid unreadable overlap where the scene turns into a bright cube soup.
- Avoid making reactivity mostly camera movement; the **objects** should react.
- If translucent cubes are used, avoid requiring heavy general OIT as a baseline. Prefer a bounded approach or visually convincing approximation.

### Recommended implementation lean
A good first shipping version is **instanced opaque / edge-lit cubes with restrained additive glow**, not a glass-heavy physically complex version.

---

## 2. Vortex Tunnel

### Fixed card / orbitable 3D stage (required)
The tunnel is genuine scene-space geometry **inside** the unmoving bordered Quick card. The operator may orbit the camera to inspect ring depth; the music does **not** commandeer the orbit camera, physically rotate the card or force rapid first-person travel. Limit camera ranges / fit as necessary to retain a readable tunnel and preserve card clipping.

**Included mock:** `neon_vortex_tunnel_low_and_high_react.png`

### Concept
A forward-drawing neon tunnel or vortex built from segmented rings, streaks, lanes, or repeated geometric arcs. Low react is calmer, darker, and more legible. High react increases rotational energy, streak density, brightness, and forward-flow speed.

### Feasibility
**Feasible with future shared Scene3D architecture.**
This is a strong candidate because the geometry can be generated procedurally and driven by a compact parameter set.

### Architecture needed for genuine parity
- Parametric or procedurally generated tunnel geometry / ring stacks.
- Mode-owned logical state for:
  - tunnel twist / rotation,
  - lane flow speed,
  - streak density,
  - pulse frequency,
  - bloom strength.
- Shared Scene3D primitives for line / strip drawing, or instanced repeated geometry.
- Optional motion blur support as a controlled, opt-in enhancement; blur is never required to communicate the movement and must not obscure a narrow card.
- Quality tiers that bound ring count, subdivision, streak layers, and post effects.
- Spec-owned settings for tunnel width, twist, speed, pulse intensity, streak density, brightness, and colour palette.

### Reactivity contract
Primary reactive changes should be:
- perceived forward flow,
- ring / lane brightness,
- rotational energy,
- streak density.

Secondary reactive changes may include:
- local warping of the tunnel profile,
- pulse waves running down the tunnel.

### Pitfalls to avoid
- Avoid motion sickness: do not rely on violent camera shake or disorienting perspective shifts.
- Avoid instant speed jumps that feel alarming instead of musical.
- Avoid saturating the whole screen into a bloom-white blur at high react.
- Avoid making low react too dead; there should still be subtle motion and a living sense of depth.
- Keep a stable visual grammar: the user should still perceive “tunnel” rather than arbitrary abstract streaks.

### Recommended implementation lean
Prefer **object / tunnel motion and segment energy** over heavy camera movement. The scene itself should feel reactive while preserving comfort.

---

## 3. Neon Lake Basin *(Shockwave Grid rework candidate)*

### Fixed card / orbitable 3D stage (required)
Keep the existing bordered widget shell stationary while its terrain, water and sky render inside the card using canonical 3D camera/orbit and CUSTOM geometry. The design target is the existing **Neon Lake Basin** low/high mock supplied in this archive; the rework is an explicitly coupled **Shockwave Grid spec migration + renderer/editor replacement**, not merely a new shader preset and not a second independent mode clock.

**Included mock:** `neon_lake_basin_low_and_high_react.png`

### Concept
A rework direction for Shockwave Grid in which the flat plane becomes a custom terrain basin surrounding water. Terrain that is **not pulled up** is treated as water. Both the surrounding terrain and the lake surface react. The scene keeps the neon wireframe / synthwave identity while adding more visual interest and stronger authoring potential.

### Feasibility
**Strong candidate as a Shockwave Grid evolution path.**
This is one of the most compelling grounded ideas because it reuses the existing shockwave identity while solving the “flat grid disappointment” problem through geometry.

### Architecture needed for genuine parity
- Reuse the existing Shockwave Grid onset/event model, Spectrum-shaped authority where applicable, and shared 3D orbit/project/antialiased grid foundations. The migration to the new spec declarations and complete Neon Lake Basin replacement happen together in the explicitly scheduled Shockwave slice; no “migration done” marker before the terrain work is delivered and accepted.
- Replace or extend the flat displaced surface with a **terrain editor driven heightfield**.
- Terrain authoring model:
  - heightfield / control mesh / authored terrain profile,
  - any region **not raised from the authored zero/base terrain** is classified as water (not a random post-processed puddle); classification follows terrain edits and is stable under audio deformation,
  - editor authoring is shape/height painting or sculpting over the basin with undo/reset/persistence through the existing Custom owner, not a new parallel source of truth,
  - raised areas become mountains / basin walls / islands.
- Separate, controllable surface responses for:
  - water ripples / travelling rings and reflective shimmer,
  - terrain ridge illumination / localized pulse and **gentle** height response (no jelly mountains). 
- Separate water/terrain material variants and reflection terms must use consistent world-space coordinates so that orbit/tilt remains correct, without animating the fixed widget border.
- Material split between water-like regions and terrain-like regions, while preserving the neon wireframe aesthetic.
- Spec-owned controls for:
  - terrain editing,
  - water behaviour,
  - mountain response,
  - shockwave speed,
  - shockwave height,
  - horizon / glow behaviour,
  - colour balance.
- Quality tiers for terrain resolution, line density, ripple detail, bloom, and optional reflections.

### Reactivity contract
Primary reactive changes should be:
- water ripples / ring propagation,
- mountain edge glow and contour activation,
- local terrain breathing / rise-fall emphasis,
- intensity of the lake / basin illumination.

Secondary reactive changes may include:
- energy traces travelling along ridges,
- subtle water shimmer,
- horizon pulse or distant terrain glow.

### Pitfalls to avoid
- Do **not** make it just “Shockwave Grid with random bumps.”
- The terrain editor must be the core authoring model, not an afterthought.
- Water and terrain need distinct reactive behavior; if both move identically, the concept loses its purpose.
- Avoid turning the mountains into jelly. Terrain should feel solid even when reactive.
- Avoid overcomplicating the custom editor beyond what the new spec method can own cleanly.

### Recommended implementation lean
This should be treated as **a terrain-authored Shockwave family mode**, not a generic shape editor variant. The terrain model is the feature.

---

## 4. Ember Swarm

### Fixed card / orbitable 3D stage (required)
A true depth-layered particle/flow scene inside the **normal static SRPSS card and border**, with camera orbit/tilt operating only on its interior 3D stage. The particles and coherent swirl rotate musically; the card never does. Stable seeded swirl groups should read as a curved volume from oblique views, not a single flat billboard pretending to be 3D.

**Included mock:** `ember_swarm_low_to_high_reactivity.png`

### Concept
A warm particle field of ember-like motes and curved trails. Low react is sparse and softly rotating, with smooth, gentle shape changes. High react increases rotational flow, particle density, trail length, glow warmth, and local energy while still preserving a graceful, non-explosive motion language.

### Feasibility
**Feasible with the planned particle-field substrate.**
This maps well to the documented future particle direction and would benefit directly from shared particle and trail helpers.

### Architecture needed for genuine parity
- Shared particle extensions (the planned particle-field path / reusable population substrate).
- Mode-owned flow field / attractor logic for gentle rotation and coherent curling motion.
- Sprite or streak rendering for embers, with optional layered trail behavior.
- Shared bloom support and depth-aware or safely bounded particle layering; no per-particle Python-side updates each frame.
- Seeded, smooth vector flow and bounded curl/attractor evolution to retain **rotation and gentle shape changes** as the music intensifies. Parameterize swirl size, rotation, curvature and separate energy lanes in spec settings rather than pure sparkle/count changes.
- Quality tiers for particle count, trail count, trail lifetime, 3D density and glow cost.
- Spec-owned settings for:
  - particle count,
  - orbit / swirl strength,
  - shape smoothness,
  - trail length,
  - colour warmth,
  - burst response,
  - density ceilings.

### Reactivity contract
Primary reactive changes should be:
- rotational energy,
- smooth shape change,
- particle density,
- trail length,
- colour warmth,
- glow.

Secondary reactive changes may include:
- local ignition bursts,
- lane differentiation,
- depth spread.

### Pitfalls to avoid
- Do not reduce reactivity to “more particles = more react.”
- Avoid hard chaotic explosions that abandon the smooth ember identity.
- Avoid noisy flicker; embers should shimmer, not strobe.
- Avoid shape change that becomes jitter instead of flow.
- Preserve graceful continuity across quiet-to-loud transitions.

### Recommended implementation lean
Use **flow coherence** as the defining feature. The ember swarm should feel like a living rotating field, not fireworks.

---

## 5. Waveform Ribbon

### Fixed card / orbitable 3D stage (required)
**Required presentation:** the standard unmoving Qt Quick widget card, border and rounded clip surround an **orbitable 3D ribbon scene**. Only the camera *within the card* changes orientation, with the existing 3D CUSTOM/freeform geometry SSOT. The ribbons weave and fold with genuine visible spatial depth and normal/view-dependent lighting, rather than a flat 2D screen-space shape. Camera orbit should reveal the geometry and **floor beneath it** while never dragging, skewing or rotating the widget card.

### Wet concrete / road-tar reflective floor (required for parity)
The approved visual target is a **dark wet concrete / road-tar floor inside the 3D scene, directly underneath the floating ribbons**. Its rough, puddled reflective appearance and coloured ribbon reflections are **not optional decorative backdrop art**: the floor is a major part of the composition in both mock states. Model it as actual scene geometry with appropriate surface normals/roughness, puddle/wetness variation, specular falloff and reflected cyan/magenta/ribbon light. Reflections must look grounded from relevant orbit angles; avoid a static photograph/reflection pasted beneath the card or into its Qt border. A measured bounded planar reflection/secondary scene pass or proven view-aware approximation is acceptable if convincing; future G1/G3 optics resources may upgrade it but must remain opt-in and isolated. A low tier may simplify the material/reflection path, but at least one curated preset / quality tier must reach credible mock-like reflective parity. No permanent reflection pass while dormant.

**Included mock:** `neon_waveform_ribbon_calm_to_intense.png`

### Concept
One or more waveform-like ribbons weave and fold through space. Low react keeps the ribbon elegant and restrained. High react allows more pronounced weaving, folding, colour and brightness response, but it should **never lose grace**.

### Feasibility
**Feasible, but needs the reusable ribbon primitive to exist properly.**
This aligns directly with the roadmap’s Waveform Ribbon direction, but it depends on a clean shared ribbon / history substrate rather than one-off bespoke geometry.

### Architecture needed for genuine parity
- Reusable **scene-space 3D** ribbon primitive(s) in the shared graphics substrate, with normals/material orientation and orbit-safe camera/projected thickness.
- Bounded scene floor mesh/material, dark concrete/road-tar wetness/roughness/puddle textures or procedural maps, and a physically coherent reflection strategy (controlled planar reflection pass where justified; otherwise a tested view-dependent approximation). Preserve floor clipping under the stationary card and correct ribbon-to-floor world coordinates.
- Historical waveform / band / curve data feeding the ribbon path.
- Mode-owned deformation logic for:
  - ribbon amplitude,
  - folding amount,
  - layering,
  - thickness,
  - light response.
- Likely multiple ribbon layers for a richer scene.
- Bounded transparency / compositing strategy, or a strong opaque/additive approximation if full translucent layering is too costly.
- Quality tiers for ribbon count, segment resolution, trail/history length, and glow.
- Spec-owned settings for curve behavior, thickness, fold intensity, ribbon count, colour response, and graceful-motion ceilings.

### Reactivity contract
Primary reactive changes should be:
- colour,
- brightness,
- light intensity,
- weave / fold depth,
- secondary layer emphasis.

Geometry should react, but the **first impression** should still be elegant, not violent.

### Pitfalls to avoid
- This mode is especially vulnerable to overreacting. Do **not** let it whip around wildly.
- Avoid folding so aggressively that the silhouette becomes unreadable.
- Avoid using sudden harsh oscillation as the main high-react signal.
- Avoid making low react too static; there should still be slow, living movement.
- If multiple ribbons are present, avoid them blending into a single mush.

### Recommended implementation lean
Bias the response model toward **colour, brightness, glow, and controlled deformation first**, with geometry amplitude changes kept musical and graceful.

---

## 6. Orbit Lattice

### Fixed card / orbitable 3D stage (required)
Nodes, orbital lanes and independently separated energy rings occupy shared scene depth **inside** the standard static card. The operator's orbit changes the internal camera, not the card; musical orbital/group rotation remains a separate mode-owned animation signal. Retain orbit-lane readability at oblique viewpoints and avoid angle-dependent visual collapse.

**Included mock:** `orbit_lattice_reactive_space_comparison.png`

### Concept
A structured orbital system of nodes and energy lanes. Low react uses fewer nodes, slower orbits, clear lane separation, and restrained glow. High react increases node count, orbit energy, lane activity, particle density, and brightness, while preserving readable structure.

### Feasibility
**Feasible and promising.**
This is a strong candidate because it can combine clean geometry, clear reactivity, and interesting authoring without needing extremely exotic rendering.

### Architecture needed for genuine parity
- Instanced node rendering.
- Reusable curve / lane representation for orbit paths.
- Mode-owned orbital state controlling:
  - orbit speed,
  - lane separation,
  - node count,
  - lane occupancy,
  - energy pulses,
  - particle accents.
- Optional particle trails or orbit streaks.
- Quality tiers for node count, lane count, trail density, and post effects.
- Spec-owned settings for orbit families, lane separation, population, speed response, glow, lane energy, and colour palette.

### Reactivity contract
Primary reactive changes should be:
- orbit speed,
- lane separation / openness,
- node activity,
- particle density,
- brightness.

Secondary reactive changes may include:
- energy pulses moving along lanes,
- rotation of whole orbital groups,
- selective emphasis of sub-lattices.

### Pitfalls to avoid
- Avoid degenerating into spaghetti. Structure is the entire appeal.
- Avoid high react causing all lanes to collapse into the same region.
- Avoid making node count the only response variable.
- Preserve readable energy lanes and separation opportunities.
- Avoid a dead low-react state; it should still feel active, just calmer.

### Recommended implementation lean
Emphasize **lane readability and group rotation opportunities**. High react should look richer, not merely busier.

---

## 7. Aurora Field

### Fixed card / orbitable 3D stage (required)
Aurora curtains, seed-stable stars and a distant ground/reflective plane are arranged in genuine scene space **inside a normal stationary bordered widget card**. The user may orbit/tilt the inner camera to see layered curtains and depth; the Qt Quick card and its border do not move. Deform the curtain surfaces smoothly across angle changes, and keep a believable spatial separation between aurora, particles and reflection.

**Included mock:** `aurora_field_low_and_high_react.png`

### Concept
A field of flowing aurora-like ribbons or curtains over a reflective or atmospheric scene. Low react uses subtle movement, softer ribbons, and sparse particles / stars. High react increases ribbon swell, colour intensity, particle flow speed, and seeded star activity.

### Feasibility
**Feasible with future architecture, but visually sensitive.**
It can likely be done well with layered ribbons / sheets and controlled particle accents without requiring full volumetric simulation. True volumetric aurora would be later and optional.

### Architecture needed for genuine parity
- Layered ribbon / sheet primitives with smooth field deformation.
- Noise / field-driven slow deformation for aurora curtains.
- Optional star or particle layer with controlled flow / activation.
- Shared bloom / **view-aware reflection** support for the aurora/ground scene; do not make a flat wallpaper carry all the apparent spatial depth.
- Deterministic seeded star field and musical star/particle flow controls (brightness, visibility, particle speed) that don't reseed randomly on each beat; use actual event-responsive flow modulation, not high-frequency jitter.
- Quality tiers for curtain layers, mesh resolution, particle count, reflection tier and post effects.
- Spec-owned settings for:
  - ribbon count,
  - swell strength,
  - deformation speed,
  - colour intensity,
  - particle flow speed,
  - seeded star activity,
  - atmospheric glow.

### Reactivity contract
Primary reactive changes should be:
- ribbon deformation / swell,
- colour intensity,
- glow,
- particle flow speed,
- seeded star activity.

Secondary reactive changes may include:
- ribbon breadth,
- vertical reach,
- local concentrated brightenings.

### Pitfalls to avoid
- Do not let it devolve into generic noisy particles with some colour behind them.
- Preserve the identity of **aurora sheets / curtains**.
- Avoid strobing or harsh flicker.
- Avoid overly violent shape changes that break the tranquil-to-grand visual language.
- Make sure high react is visually stronger without becoming alarming.

### Recommended implementation lean
Treat this as **structured flowing sheets first, particles second**. The aurora body is the mode; particles are support.

---

## 8. Matrix / Digital Rain

**Included mock:** `matrix_digital_rain_visualizer_concept.png` (one two-state reference sheet: low-react / high-react).

### Concept and visual identity
Classic **Matrix-style falling green code**, not an abstract equalizer that happens to use text. Continuous vertical streams keep a nearly constant, individually seeded fall speed; the scene has depth-separated columns, bright leading glyphs and fading green tails. Quiet music leaves thin dark streams and selective highlights. Loud passages create richer layers, longer and brighter trails, controlled glyph mutation, additional active columns and energy passing **through** the characters. The code's fall must remain readable and comfortable, with no nausea-inducing sudden acceleration.

### Fixed card / 3D orbitable stage (required)
This is a **normal flat SRPSS widget card**, with stationary border, shadow, Edit handle, and rounded viewport clip. Only its inner **3D Digital Rain world** has a user-orbitable camera, just like the planned Extruded Bubble camera-in-card arrangement. Do not turn the card into a floating 3D object or rotate the on-screen GUI. Create depth-separated rain layers and columns so off-axis camera angles expose real parallax, spacing, occlusion, and graceful near/far fade. Preserve canonical per-mode camera/orbit persistence, freeform 3D CUSTOM rules and inner-card fit. The background and optional low-key wet floor may enrich depth but may not eclipse the code.

### Feasibility
**Strong in a performance-bounded form under Qt Quick / Python / OpenGL 4.6; full per-glyph 3D meshes for every character are not a sensible default.** The quality reference can be reached largely with GPU-instanced glyph planes in 3D space plus selective true volumetric glyphs, lighting, and depth effects. The camera is truly 3D even when the majority of glyphs are efficiently rendered from an atlas. No new graphics API, text widget fleet, or CPU-side update of every character is needed.

### Architecture needed for genuine parity
- Build/use a single **glyph atlas** with controlled glyph set, optional classic code styles, mip/AA controls, per-instance UV indexes and palette variants. This is source art/shader input, **not** an individual QQuickText/QPainter widget per glyph.
- Draw glyphs as **instanced world-space quads** batched by material/layer with small GPU per-column state (position, fall phase, speed seed, length, frequency lane, glyph seed, active energy); shader or compute-based deterministic glyph variation and instance filtering. Avoid uploading complete glyph transforms or doing per-glyph Python work on every frame.
- Render **several depth layers** with camera-perspective parallax and occlusion; use graded fog/near-far attenuation and smooth per-column/per-glyph entry and exit fades so glyphs too near, too distant, or past a column's travel extent dissolve instead of clipping abruptly.
- For near foreground glyphs, support an **optional measured 3D LOD**: a bounded population of extruded glyph meshes or thickness-impostor variants, replacing/augmenting select atlas quads as the operator orbits. Distant glyphs remain batched quads. The whole rain field must not instantiate 3D mesh geometry for thousands of characters by default. Oblique angles must not cause the entire code wall to vanish from backface culling; tune facing/orientation and bounded volumetric close detail deliberately.
- A slow constant fall is driven by the *existing logical animation time*, not a new clock; stable per-column seeds and positions persist across latest-wins publication. Existing shared audio snapshot/transient events and a mode-owned lightweight reaction state drive authored levels; no second capture/DSP/AGC authority.
- Use already-shared Scene3D orbit/projection, std140/std430 stream ownership, optional particle/instancing/compute facilities, SceneTarget/overlay and opt-in bloom. If G3 transparency and optics are not yet landed, use a convincing sorted/additive/faded glyph approximation as the measured baseline rather than creating a private OIT compositor.
- Reactivity mapping must be **local and zoned**: associate frequency lanes with stable columns or subgroups; event-driven illumination ripples intersect currently falling glyphs in world/scene space, leaving the movement untouched.
- Spec-owned settings include glyph atlas/style, density ceiling, character size, fall speed and variation, trail length, mutation intensity, colour gradient and head highlights, frequency-lane mapping, transient-wave spread/strength/decay, near/far fade, depth layer count and spacing, seeded scene ambience, orbit limits, optional close-up solid-glyph tier, reflective floor presence, and tier-specific emission/particle caps. Use conditional controls for optional costly features; persist camera and geometry at their canonical owner, not duplicated in presets.
- Explicit quality ceilings for drawn glyph count, layer count, shader complexity, draw calls, close-range solid glyphs, emission and any reflection targets. Keep disabled/unselected mode allocations zero and retire at normal park/context destruction; no simulation when dormant.

### Two-state artistic target
- **Low react:** dark readable green rain, minimal head accents, short translucent tails, sparse depth planes, slow stable downward cadence, subtle glyph mutation, limited floor reflection.
- **High react:** more active streams, controlled tail elongation, brighter glyph heads, selective column illumination, more visible depth layering, musical glyph changes and bounded waves travelling through nearby glyphs; the rain's descent remains recognizably the same speed. Brightness and glow grow locally, **never a green-white wall**.

### Musical reactivity contract and separation
- **Bass / strong transients:** a **localized** ripple of illumination passing through selected columns (or a projected wave through the 3D character field), transiently brightening characters and their wet-floor reflections. Use existing onset identity/time/strength; strong bass must *not* globally elevate the emission floor, spawn all columns, or permanently increase scrolling speed.
- **Midrange:** increased glyph mutation and activity of allocated frequency-lane groups; hold positions and glyph legibility.
- **Treble:** restrained white-hot leading-character accents and small fast-scoped glints, not strobing the entire screen.
- **Sustained musical level:** gentle density/trail-length/brightness evolution and layer differentiation, with capped/limited combined radiance even during consecutive loud passages.
- **Idle / very quiet:** natural seeded falling movement continues, with low emission, intermittent harmless glyph turnover and steady visual continuity; dormant/off remains truly dormant.

### Specific pitfalls and negative controls
- **The bass-washout trap is priority one:** do not respond to each kick by simultaneously increasing every stream's brightness, bloom, trail length, particle count and scroll speed. Constrain emission per source/region and whole scene, preserve contrast, use localized one-shot envelopes rather than global screen flashes, and measure sustained-loud/rapid-onset clips explicitly. Visual compare must include dark details still recognizable under repeated kicks.
- **Motion sickness:** no large automatic camera spins, scene zooms, whole-wall yanking, step-speed changes or rapidly repeating full-width moving bands. User orbit is intentional direct input; an audio response is not permission to move the camera.
- **Spatial legibility:** glyph quads at grazing angles can vanish, overlap into illegible noise, or look flat despite the camera; prove readability at multiple turn/tilt angles and use a deliberately bounded 3D near-field tier to solve, not unrestricted extruded glyphs.
- **Temporal aliasing:** no hard per-frame random glyph reseed, flashing head selection, or popping new dense columns; use stable seeds, continuity, attack/release, entrance/exit fading and non-competing wave envelope ownership.
- **Floor and bloom:** reflective floor is optional for this mode and deliberately subordinate; glow must illuminate select strokes without erasing the code.
- **Performance:** do not allocate one draw call / mesh / Python object / texture per glyph, and do not perform full-viewport screen work every frame solely to make characters look extruded. Stress-test worst-case max-density, multi-layer, camera orbit and continuous loud audio on dual 1440p displays.

### Acceptance bar
At least one user-authorable curated preset must reach recognizable **low/high paired-mock parity** with traditional falling-code identity, real perceived 3D depth under manual orbit, and energetic but **controlled** music response. Validate real song quiet/loud/onset sections alongside deterministic synthetic clips; inspect that repeated transients do not blow out the green palette or destabilize the code, and log meaningful per-display CPU/GPU deltas before promotion. Preserve editable presets and a separate CUSTOM state.

---

## Cross-cutting architecture requirements for all eight

These selected modes must stand up as production visualizers inside **ordinary stationary bordered SRPSS cards**. “Framed 3D” means **the camera moves inside the card, not the card in world space**. The shared Scene3D/Qt Quick composition owns the video output; the per-mode logical runtime owns the musical state. Some facilities already exist, others are explicitly staged future work, and the implementation must be measured, not presumed from artwork.

### A. Spec-method integration (mandatory, including Digital Rain)
Every mode should be a properly spec-declared mode in the **new visualizer spec method** (`core/settings/visualizer_mode_settings.py` and its mode-owned declarations), with:
- canonical defaults,
- settings declarations,
- conditional controls where needed,
- serialization / preset boundaries,
- dormant disabled behavior,
- capability ownership,
- no hidden alternate control owner,
- single canonical per-mode camera/pose and CUSTOM geometry ownership instead of preset-managed duplicates,
- any bespoke terrain or other interactive editor retaining existing Custom Save/Cancel/Restore/Reset semantics rather than bypassing the spec.

**Special case:** Neon Lake Basin is **not** to be added as a new independent look while old Shockwave Grid remains separate; its completed spec integration and terrain/water rework should be one auditable implementation slice as requested in `Current_Plan.md`. Existing behavior/presets may need explicit compatibility rules and migration, not a silent loss of authored content.

### B. Shared Scene3D / render substrate
Needed broadly across the set:
- canonical shared Scene3D view/orbit/projection primitives driving only the inner 3D stage,
- retained Qt Quick card chrome, clipping, opacity, animation, geometry and Edit controls without becoming a 3D box itself,
- instanced mesh drawing,
- line / strip / lane rendering,
- ribbon support,
- particle / streak support,
- bounded bloom and post-process options,
- opt-in physically convincing wet concrete/road-tar scene-floor materials and scene-space ribbon reflections,
- depth-aware instanced glyph atlas rendering and distance-based LOD/fading for Digital Rain,
- strict lazy resource ownership and retirement.

### C. Logical runtime discipline
For each mode:
- no second audio authority,
- no second clock and no audio-driven camera spin (direct camera interaction only),
- no special repaint loop,
- latest-wins snapshot publication,
- bounded logical state,
- deterministic or at least stable react behavior under fixed input.

### D. Quality tiers and performance fences
Every mode needs hard ceilings for:
- instance count,
- particle count,
- subdivision / resolution,
- trail length,
- ribbon layers,
- post-process intensity.

Disabled or inactive modes must allocate nothing meaningful.

### E. Reactivity safety rules
Across the selected set:
- strong response should not default to violent geometry spasms or motion-sickness-inducing whole-scene/camera movement,
- **bass and transients must not wash out the image**: keep local transient impulses and a combined radiance/bloom budget; prove this with repeated-kick and sustained-loud-passage replays,
- colour / brightness / density / speed are often safer first response channels,
- quiet passages must remain alive, not dead,
- loud passages must become richer, not merely more chaotic,
- preserve mode identity under both low and high react states,
- independently assess responsive shape, trails, and light: a mode is not musically expressive if only its luminance changes,
- retain actual time-dependent musical dynamics, not a static mock with an artificially elevated glow slider.

### F. Mock, geometry and reactivity acceptance
- **All eight images:** retain the paired low/high targets as authored visual references; images are not shader blueprints or immutable test goldens. At least **one accepted/editable preset per mode** should have strong appearance parity and convincing response across quiet, onset-rich and sustained-loud passages.
- **Canonical geometry:** normal card and chrome remain flat. Test internal camera orbit/tilt, shell clipping, correct perspective, 3D freeform edit/resize, canonical persistence, and per-display transfer. Do not permit camera-owned layout copies or a drifting card/scene alignment.
- **Waveform Ribbon floor:** wet concrete/road-tar material and visible, view-correct coloured reflections are **essential acceptance requirements**, not optional scene dressing for the parity preset.
- **Neon Lake Basin:** editable heightfield = terrain/water ownership, stable classification of unraised cells as water, independently reactive mountain vs water systems, transparent persistence and spec integration completed in the same rework.
- **Digital Rain:** orbitable depth layers plus stable-speed recognizably falling text; require low/high parity *and* strong negative controls for bass-induced washout, strobing and camera motion.
- **Validation:** use deterministic synthetic replay and real musical recordings from `F:\Programming\Apps\ShittyRandomPhotoScreenSaver\logs\visualizer_recordings`; preserve the recording path in test guidance. Evaluate low/high states, transitions, near-silence, sustained loudness and repeated bass on actual single- and dual-1440p configurations; evaluate frame-time tails as well as median. Run the smallest focused proofs first and follow operator-directed build/test rules.

---

## Priority / difficulty lean

A practical order if these were ever promoted beyond concept stage:

### Easier / clearer first candidates
1. Reactive Cubes (instanced, opt-in edge illumination)
2. Vortex Tunnel (procedural, stable inward view)
3. Orbit Lattice (separate lane families)
4. Matrix / Digital Rain (batched atlas glyphs with depth; **not** full-mesh glyph population)
5. Neon Lake Basin (reuses Shockwave ownership, but terrain editor/material boundary adds authoring cost)

### Medium complexity with strong payoff
6. Ember Swarm (coherent 3D flows with bounded particle/trail budget)
7. Aurora Field (layered curtains and view-correct atmosphere)

### Most sensitive to overreaction and implementation nuance
8. Waveform Ribbon (smooth folding *and* the required wet reflective floor)

This difficulty order is not an artistic ranking; it is a pragmatic “how cleanly it maps onto the architecture” lean.

---

## Final note

These concepts are worth keeping, but they should only graduate into real implementation work if they can satisfy SRPSS’s existing architectural standards:

- spec-owned mode behavior,
- lazy and bounded GPU/resource ownership,
- dormancy when inactive,
- no duplicate runtime authorities,
- visually convincing musical response,
- and acceptable performance on the actual target environment.

The key recurring reactivity lesson from these selections is simple:

> **High react should be musically unmistakable, richer and deeper without panicked motion, flattened luminance, jarring geometry, or lost scene identity; bass hits should never make everything white or uniformly bright.**

